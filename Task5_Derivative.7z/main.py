import sys
import csv
import numpy as np
from sympy import symbols, sympify
from sympy.utilities.lambdify import lambdify
import math
# import random
import matplotlib.pyplot as plt
from PyQt6.QtWidgets import QApplication, QWidget, QFileDialog, QMessageBox, QVBoxLayout, QTableWidget, QTableWidgetItem
from DerivativeUI import Ui_Form
from PyQt6.QtCore import QRegularExpression
from PyQt6.QtGui import QRegularExpressionValidator
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class Derivative(QWidget):
    def __init__(self):
        super().__init__()

        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.initializeUI()
        np.set_printoptions(precision=3)
        # self.show()
        self.setGeometry(100, 100, 950, 600)
        self.func_text = '-2*x**3'
        self.deriv_func_text = '-6*x**2'
        self.deriv2_func_text = '-12*x'
        self.x0 = 1
        self.dx = 0.0001
        self.derivs = {}
        self.derivs2 = {}
        self.order = 'Перша похідна'

    def initializeUI(self):

        # Знайти віджет QGraphicsView за ім'ям ("graphicsView")
        self.ui.graphicsView = self.findChild(QWidget, "graphicsView")

        # Створити віджет графіка Matplotlib
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)

        # Отримати поточні вісі для побудови графіка
        self.ax = self.figure.add_subplot(111)
        # Встановлення размеру шрифта для поділок на вісях
        self.ax.tick_params(axis='both', labelsize=8)

        layout = QVBoxLayout(self.ui.graphicsView)
        layout.addWidget(self.canvas)
        # self.ui.horizontalLayout_8.addWidget(self.canvas)

        #validation
        self.ui.func_entry.setPlaceholderText("Введіть формулу в нотації Python")
        self.ui.analit_entry.setPlaceholderText("Введіть формулу в нотації Python")
        self.ui.analit2_entry.setPlaceholderText("Введіть формулу в нотації Python")
        regex1 = QRegularExpression("-?[0-9]+\.?[0-9]*")
        self.ui.a_entry.setValidator(QRegularExpressionValidator(regex1))
        self.ui.b_entry.setValidator(QRegularExpressionValidator(regex1))
        self.ui.x0_entry.setValidator(QRegularExpressionValidator(regex1))
        self.ui.delta_entry.setValidator(QRegularExpressionValidator(regex1))

        # Add signal/slot connections for buttons
        self.ui.plot_button.clicked.connect(self.run_plot)
        self.ui.culcButton.clicked.connect(self.run_derivative)

        # clear table
        self.ui.button_clear.clicked.connect(self.clear_table)
        # save to file
        self.ui.save_button.clicked.connect(self.save_table_file)

    def f(self, x):
        pass

    def run_plot(self):
        func_text = self.ui.func_entry.text()
        if func_text == '':
            func_text = self.func_text
        try:
            f = self.convert_to_func(func_text)
        except Exception as e:
            self.ui.result_label.setText(f'Помилка у перетворені тексту в функцію: {str(e)}')
            return
        self.plot(f)

    def run_derivative(self):

        self.ui.result_label.setText('')
    # Convert all inputs in approptiate values
        func_text = self.ui.func_entry.text()
        deriv_func_text = self.ui.analit_entry.text()       
        if func_text == '':
            func_text = self.func_text
        if deriv_func_text == '':
            deriv_func_text = self.deriv_func_text
        try:
            f = self.convert_to_func(func_text)
            f_deriv = self.convert_to_func(deriv_func_text)
        except Exception as e:
            self.ui.result_label.setText(f'Помилка у перетворені тексту в функцію: {str(e)}')
            return

        self.x0 = float(self.ui.x0_entry.text())
        self.dx = float(self.ui.delta_entry.text())

    # Calculate y
        try:
            y = round(f(self.x0), 4)
        except:
            self.ui.result_label.setText(f'Функція не існує в точці')
            return

        self.order = self.ui.combo_derivative.currentText()

    # Extremums
        extremum_points = self.func_extremums(f)

    # Calculate 1-order derivative
        if self.order == 'Перша похідна':
            y_deriv_analit = self.first_derivative(f, f_deriv)
            self.update_table(y, y_deriv_analit)
            self.plot_result(f, ext_points = extremum_points)

    # Calculate 2-order derivative        
        if self.order == 'Друга похідна':
            # Convert all inputs in approptiate values
            deriv2_func_text = self.ui.analit2_entry.text()       
            if deriv2_func_text == '':
                deriv2_func_text = self.deriv2_func_text
            try:
                f_deriv2 = self.convert_to_func(deriv2_func_text)
            except Exception as e:
                self.ui.result_label.setText(f'Помилка у перетворені тексту в функцію: {str(e)}')
                return

            # 2-order derivative
            y_deriv2_analit = self.second_derivative(f, f_deriv2)
            self.update_table(y, y_deriv2_analit)

    # Inflection points

            inflection_points = self.func_inflection_points(f)
            self.plot_result(f, ext_points = extremum_points, infl_points = inflection_points)


    def convert_to_func(self, func_text):
        # variables in math expressions
        x = symbols('x')
        y = symbols('y')
        z = symbols('z')
        # convert text to SymPy object
        expression = sympify(func_text)
        # function from expression, use numpy to optimize work
        # with NumPy objects if variables or result are arrays
        return lambdify(x, expression, 'numpy')

    # Calculate 1-order derivative
    def first_derivative(self, f, f_deriv):
        try:
            y_deriv_analit = round(f_deriv(self.x0), 4)
        except:
            self.ui.result_label.setText('Функція не диференційована в точці')
            return

        y_deriv_right = self.derivative_right(f, self.dx, self.x0)
        y_deriv_left = self.derivative_left(f, self.dx, self.x0)
        y_deriv_mid = self.derivative_middle(f, self.dx, self.x0)
        self.derivs = {'y_deriv_right': y_deriv_right, 'y_deriv_left': y_deriv_left, 'y_deriv_mid': y_deriv_mid}

        return y_deriv_analit

    # Calculate 2-order derivative
    def second_derivative(self, f, f_deriv2):
        try:
            y_deriv2_analit = round(f_deriv2(self.x0), 4)
        except:
            self.ui.result_label.setText('Функція не диференційована в точці')
            return

        y_deriv2_right = self.derivative2_right(f, self.dx, self.x0)
        y_deriv2_left = self.derivative2_left(f, self.dx, self.x0)
        y_deriv2_mid = self.derivative2_middle(f, self.dx, self.x0)
        self.derivs2 = {'y_deriv2_right': y_deriv2_right, 'y_deriv2_left': y_deriv2_left, 'y_deriv2_mid': y_deriv2_mid}

        return y_deriv2_analit

    # Числельне обчислення першої похідної
    def derivative_right(self, f, dx, x0):
        return (f(x0+dx) - f(x0))/dx

    def derivative_left(self, f, dx, x0):
        return (f(x0) - f(x0-dx))/dx

    def derivative_middle(self, f, dx, x0):
        return (f(x0+dx) - f(x0-dx))/(2*dx)

    # Числельне обчислення другої похідної
    def derivative2_right(self, f, dx, x0):
        return (f(x0+2*dx) - 2*f(x0+dx)+ f(x0))/(dx*dx)

    def derivative2_left(self, f, dx, x0):
        return (f(x0) - 2*f(x0-dx) + f(x0-2*dx))/(dx*dx)

    def derivative2_middle(self, f, dx, x0):
        return (f(x0+2*dx) + f(x0-2*dx) - 2*f(x0))/(4*dx*dx)

    # Extremums and inflection points
    def iterations_multiple_root(self, f, a, b, iterations_num):
        roots = []
        h = (b - a)/iterations_num
        for i in range(iterations_num):
            sign = f(a + h*i)*f(a + h*(i+1))
            if sign < 0:
                roots.append((a+a+h*i+h*i+h)/2)
            if sign == 0:
                roots.append(a + h*i) if f(a + h*i) == 0 else roots.append(a + h*(i+1))
        return roots

    def func_extremums(self, f):
        # function to call another function with predefined arguments
        def call_derivative(x):
            return self.derivative_middle(f, self.dx, x)

        a = float(self.ui.a_entry.text())
        b = float(self.ui.b_entry.text())

        extremums_x = self.iterations_multiple_root(call_derivative, a, b, 10000)
        extremums_y = []
        if len(extremums_x) > 0:
            extremums_y = [f(x) for x in extremums_x]

        return (extremums_x, extremums_y)    


    def func_inflection_points(self, f):
        # function to call another function with predefined arguments
        def call_derivative2(x):
            return self.derivative2_middle(f, self.dx, x)

        a = float(self.ui.a_entry.text())
        b = float(self.ui.b_entry.text())

        inflection_x = self.iterations_multiple_root(call_derivative2, a, b, 10000)
        inflection_y = []
        if len(inflection_x) > 0:
            inflection_y = [f(x) for x in inflection_x]
        print(inflection_x)
        print(inflection_y)

        return (inflection_x, inflection_y)

    def update_table(self, y, y_deriv_analit):
        table = self.ui.tableWidget
        row_position = table.rowCount()
        table.insertRow(row_position)
        table.setItem(row_position, 1, QTableWidgetItem(f"{self.x0}"))
        table.setItem(row_position, 2, QTableWidgetItem(f"{self.dx}"))
        table.setItem(row_position, 3, QTableWidgetItem(f"{y}"))
        if self.order == 'Перша похідна':
            table.setItem(row_position, 0, QTableWidgetItem(f"1"))
            table.setItem(row_position, 4, QTableWidgetItem(f"{y_deriv_analit}"))
            table.setItem(row_position, 5, QTableWidgetItem(f"{str(round(self.derivs['y_deriv_right'], 4))}"))
            table.setItem(row_position, 6, QTableWidgetItem(f"{str(round(self.derivs['y_deriv_left'], 4))}"))
            table.setItem(row_position, 7, QTableWidgetItem(f"{str(round(self.derivs['y_deriv_mid'], 4))}"))
        if self.order == 'Друга похідна':
            table.setItem(row_position, 0, QTableWidgetItem(f"2"))
            table.setItem(row_position, 4, QTableWidgetItem(f"{y_deriv_analit}"))
            table.setItem(row_position, 5, QTableWidgetItem(f"{str(round(self.derivs2['y_deriv2_right'], 4))}"))
            table.setItem(row_position, 6, QTableWidgetItem(f"{str(round(self.derivs2['y_deriv2_left'], 4))}"))
            table.setItem(row_position, 7, QTableWidgetItem(f"{str(round(self.derivs2['y_deriv2_mid'], 4))}"))

    def plot(self, func):
            a = float(self.ui.a_entry.text())
            b = float(self.ui.b_entry.text())
            x = np.linspace(a, b, 500)
            y = []
            try:
                y = [func(xi) for xi in x]
            except:
                self.ui.result_label.setText('Функція не існує в деяких точках відрізку')
                # return

            # графік у вікні matplotlib
            plt.figure()
            plt.plot(x, y, label=self.ui.func_entry.text())
            plt.xlabel('x')
            plt.ylabel('y')
            plt.title(f'Графік функції')
            plt.legend()
            plt.grid(True)
            plt.show()

    def plot_result(self, func, **kwargs):

        ext_points = kwargs['ext_points']

        a = float(self.ui.a_entry.text())
        b = float(self.ui.b_entry.text())
        x = np.linspace(a, b, 500)
        y = []
        y_deriv = []

        try:
            y = [func(xi) for xi in x]
            y_deriv = [self.derivative_middle(func, self.dx, xi) for xi in x]
        except:
            self.ui.result_label.setText('Функція не існує або не диференційована в деяких точках відрізку')
            return
        
        # графік canvas у вікні інтерфейсу

        self.ax.clear()
        self.ax.plot(x, y, label=self.ui.func_entry.text(), color='blue', linewidth=0.75)
        self.ax.plot(x, y_deriv, label='1 похідна', color='green', linewidth=0.75)
        # self.ax.axvline(a, color='skyblue')
        # self.ax.axvline(b, color='skyblue')
        self.ax.scatter(ext_points[0], ext_points[1], label='точки екстремуму', color='red', marker='.', zorder=3)
        
        if self.order == 'Друга похідна':
            infl_points = kwargs['infl_points']
            y_deriv2 = []
            try:
                y_deriv2 = [self.derivative2_middle(func, self.dx, xi) for xi in x]
            except:
                self.ui.result_label.setText('Функція не диференційована в деяких точках відрізку')
                return

            self.ax.plot(x, y_deriv2, label='2 похідна', color='pink', linewidth=0.75)
            self.ax.scatter(infl_points[0], infl_points[1], label='точки перегину', color='black', marker='^', zorder=3)

        self.ax.set_xlabel('x')
        self.ax.set_ylabel('y')
        self.ax.grid(True)
        # self.ax.set_title(f'Похідна')

        # Розмір шрифта для легенди
        # font = {'family': 'serif', 'color':  'darkred', 'weight': 'normal', 'size': 8}
        font = {'size': 6}
        plt.rc('font', **font)
        self.ax.legend(loc='upper right')
        self.canvas.draw()

    def clear_table(self):
        self.ui.tableWidget.setRowCount(0)

    def save_table_file(self):
        table = self.ui.tableWidget

        # Отримуємо дані таблиці
        data = []
        row_data = [self.ui.func_entry.text()]
        for row in range(table.rowCount()):
            for column in range(table.columnCount()):
                item = table.item(row, column)
                if item is not None:
                    row_data.append(item.text())
                else:
                    row_data.append('')
            data.append(row_data)

        # Відкрити діалогове вікно для вибору файлу та отримати шлях
        file_name, _ = QFileDialog.getSaveFileName(self, "Збереження в файл", "derivatives.csv", "CSV Files (*.csv);;All Files (*)")

        if file_name:
            try:
                with open(file_name, 'a', newline='', encoding="utf-16") as csv_file:
                    csv_writer = csv.writer(csv_file)
                    for row_data in data:
                        csv_writer.writerow(row_data)
                QMessageBox.information(self, "Success", "Таблиця успішно збережен в файл.")
            except Exception as e:
                QMessageBox.critical(self, "Помилка", f"Помилка при збереженні файла: {str(e)}")
def main():
    app = QApplication(sys.argv)
    window = Derivative()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
